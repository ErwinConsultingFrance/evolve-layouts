(function(cwApi, $) { 
  "use strict";

    /********************************************************************************
    Config
    *********************************************************************************/

    var hideElementIf = {};
    hideElementIf.config = {
        "process" : [
            {
                "style": "display",
                "styleValue": "none",
                "type" : "class", 
                "class" : "fa-question-circle",
            },
            {
                "style": "display",
                "styleValue": "none",
                "type" : "jQuerySelector",
                "query" : "[id^='pg-propertygroup_276146927']",
                "property" : "validated",
                "operator"  : "=",
                "value" : true
            }
        ],
    };


    /********************************************************************************
    Custom Action for Single Page : See Impact here http://bit.ly/2qy5bvB
    *********************************************************************************/
    cwCustomerSiteActions.doActionsForSingle_Custom = function (rootNode) { 
        var currentView, url,i;
        currentView = cwAPI.getCurrentView();

        for(i in cwAPI.customLibs.doActionForSingle) {
            if(cwAPI.customLibs.doActionForSingle.hasOwnProperty(i)) {
                if (typeof(cwAPI.customLibs.doActionForSingle[i]) === "function"){
                    cwAPI.customLibs.doActionForSingle[i](rootNode,currentView.cwView);
                }   
            }
        }
    };

    hideElementIf.do = function(rootNode){
        var config,i;
        this.viewName = cwAPI.getCurrentView().cwView;
        var doAction = true;
        if(this.config && this.config.hasOwnProperty(this.viewName)) {
            for (var i = 0; i < this.config[this.viewName].length; i += 1) {
                doAction = true;
                var tempConfig = this.config[this.viewName][i];
                if(tempConfig.hasOwnProperty("property") && tempConfig.hasOwnProperty("operator") && tempConfig.hasOwnProperty("value")) {
                    doAction = this.isActionToDo(rootNode,tempConfig);
                }
                if(doAction) {
                    this.execute(tempConfig);
                }
            }
        }
    };

    hideElementIf.isActionToDo = function(rootNode,config){
        if(rootNode) {
            var objPropertyValue;
            if(config.property == "id") {
                objPropertyValue = rootNode.object_id;
            } else {
                objPropertyValue = rootNode.properties[config.property];
            }
            switch(config.operator) {
                case "=":
                    if(Array.isArray(config.value))  {
                        for (var i = 0; i < config.value.length; i += 1) {
                           if(objPropertyValue == config.value[i] ) return true; 
                        }
                    }
                    if(objPropertyValue == config.value) return true;
                    break;
                case "<":
                    if(Array.isArray(config.value))  {
                        for (var i = 0; i < config.value.length; i += 1) {
                           if(objPropertyValue < config.value[i] ) return true; 
                        }
                    }
                    if(objPropertyValue < config.value) return true;
                    break;
                case "<=":
                    if(Array.isArray(config.value))  {
                        for (var i = 0; i < config.value.length; i += 1) {
                           if(objPropertyValue <= config.value[i] ) return true; 
                        }
                    }
                    if(objPropertyValue <= config.value) return true;
                    break;
                case ">":
                    if(Array.isArray(config.value))  {
                        for (var i = 0; i < config.value.length; i += 1) {
                           if(objPropertyValue > config.value[i] ) return true; 
                        }
                    }
                    if(objPropertyValue > config.value) return true;
                    break;
                case ">=":
                    if(Array.isArray(config.value))  {
                        for (var i = 0; i < config.value.length; i += 1) {
                           if(objPropertyValue >= config.value[i] ) return true; 
                        }
                    }
                    if(objPropertyValue >= config.value) return true;
                    break;
                case "!=":
                    if(Array.isArray(config.value))  {
                        for (var i = 0; i < config.value.length; i += 1) {
                           if(objPropertyValue != config.value[i] ) return true; 
                        }
                    }
                    if(objPropertyValue != config.value) return true;
                    break;
                default:
                    return false;
            }
        }
        return false;
    };

    hideElementIf.execute = function(config){
        if(config.hasOwnProperty("style") && config.hasOwnProperty("styleValue") && config.hasOwnProperty("type") && (config.hasOwnProperty("id")  || config.hasOwnProperty("class") || config.hasOwnProperty("query")) ) {
            switch(config.type.toLowerCase()) {
                case "tab":
                    this.actionOnId(config.style,config.styleValue,this.viewName + "-tab-" +  config.id);
                    break;
                case "jqueryselector": 
                    this.actionWithQuery(config.style,config.styleValue,config.query);
                    break;                  
                case "propertygroup":
                    this.actionOnClassAndId(config.style,config.styleValue,"cwPropertiesTableContainer",config.id.toLowerCase());
                    break;
                case "class":
                    this.actionOnClass(config.style,config.styleValue,config.class);
                    break;
                case "id":
                    this.actionOnId(config.style,config.styleValue,config.id);
                    break;
                case "view":
                    this.actionOnId(config.style,config.styleValue,"navview-" + config.id);
                    break;
                default:
                    return false;
            }
        }
    };

    hideElementIf.actionOnClass = function(style,value,className){

        var elements = document.getElementsByClassName(className);
        var i;
        for (i = 0; i < elements.length; i++) {
            elements[i].style[style] = value;               
        }
    };
 
    hideElementIf.actionWithQuery = function(style,value,query){
        try {
            $(query).css(style,value);            
        } catch(e) {
            console.log(e);
        }

    };

    hideElementIf.actionOnId = function(style,value,id){
        var element = document.getElementById(id);
        if(element && element.style) {
            element.style[style] = value;               
        }
    };
    
    hideElementIf.actionOnClassAndId = function(style,value,className,id){
        var elements = document.getElementsByClassName(className);
        var i;
        for (i = 0; i < elements.length; i++) {
            if(elements[i].id.indexOf(id)!== -1) {
                elements[i].style[style] = value;               
            }       
        }
    };



    /********************************************************************************
    Configs : add trigger for single page
    *********************************************************************************/
    if(cwAPI.customLibs === undefined) { cwAPI.customLibs = {};}
    if(cwAPI.customLibs.doActionForSingle === undefined) { cwAPI.customLibs.doActionForSingle = {};}
    cwAPI.customLibs.doActionForSingle.hideElementIf = hideElementIf.do.bind(hideElementIf); 

}(cwAPI, jQuery));