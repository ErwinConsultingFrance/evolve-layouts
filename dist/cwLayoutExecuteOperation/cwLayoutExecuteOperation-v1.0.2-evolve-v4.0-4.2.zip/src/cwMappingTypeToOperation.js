var cwConfigurationExecuteMapping = {
	"Calculation engine" : "calculate"
};