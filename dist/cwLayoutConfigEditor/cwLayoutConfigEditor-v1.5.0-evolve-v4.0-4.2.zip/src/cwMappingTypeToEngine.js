var cwConfigurationEditorMapping = {
	"Calculation engine" : "cwEngineCalculation",
	"Alert Engine" : "cwEngineAlert"
};