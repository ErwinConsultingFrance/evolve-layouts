var cwConfigurationEditorMapping = {
	"Calculation engine" : "cwEngineCalculation"
};